<?php
/**
 * Template Name: Album Posts
 */

$post_type = 'album';

get_template_part('archive'); ?>