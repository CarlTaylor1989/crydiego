<?php
/**
 * Template Name: Video Posts (List)
 */
 
$post_type = 'video';
$item_template = 'video_list';

get_template_part('archive'); ?>