<?php
/**
 * Template Name: Gig Posts
 */

$post_type = 'gig';

get_template_part('archive'); ?>