<?php
/**
 * Template Name: Blog Posts (List)
 */

$post_type = 'post';

get_template_part('archive'); ?>