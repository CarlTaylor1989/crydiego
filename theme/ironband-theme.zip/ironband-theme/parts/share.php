
				<!-- links-block -->
				<aside class="links-block">
					<div class="buttons">
<?php echo get_iron_option('custom_social_actions'); ?>
					</div>
				</aside>
