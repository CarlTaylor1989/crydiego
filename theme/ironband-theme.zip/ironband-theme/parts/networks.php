
				<!-- social-networks -->
				<ul class="social-networks">
<?php if(get_iron_option('facebook_page')): ?>
					<li><a target="_blank" class="facebook" href="<?php echo get_iron_option('facebook_page'); ?>"><i class="icon-facebook" title="Facebook"></i></a></li>
<?php endif; ?>
<?php if(get_iron_option('twitter_page')): ?>
					<li><a target="_blank" class="twitter" href="<?php echo get_iron_option('twitter_page'); ?>"><i class="icon-twitter" title="Twitter"></i></a></li>
<?php endif; ?>
<?php if(get_iron_option('instagram_page')): ?>
					<li><a target="_blank" class="instagram" href="<?php echo get_iron_option('instagram_page'); ?>"><i class="icon-instagram" title="Instagram"></i></a></li>
<?php endif; ?>
<?php if(get_iron_option('linkedin_page')): ?>
					<li><a target="_blank" class="linkedin" href="<?php echo get_iron_option('linkedin_page'); ?>"><i class="icon-linkedin" title="LinkedIn"></i></a></li>
<?php endif; ?>
<?php if(get_iron_option('soundcloud_page')): ?>
					<li><a target="_blank" class="soundcloud" href="<?php echo get_iron_option('soundcloud_page'); ?>"><i class="icon-soundcloud" title="Soundcloud"></i></a></li>
<?php endif; ?>
<?php if(get_iron_option('vimeo_page')): ?>
					<li><a target="_blank" class="vimeo" href="<?php echo get_iron_option('vimeo_page'); ?>"><i class="icon-vimeo" title="Vimeo"></i></a></li>
<?php endif; ?>
<?php if(get_iron_option('youtube_page')): ?>
					<li><a target="_blank" class="youtube" href="<?php echo get_iron_option('youtube_page'); ?>"><i class="icon-youtube" title="YouTube"></i></a></li>
<?php endif; ?>
				</ul>
